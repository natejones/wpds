jQuery(document).ready(function ($) {
  $.simpleWeather({
    location: 'Grand Rapids, MI',
    woeid: '',
    unit: 'f',
    success: function(weather) {
      html = '<i class="icon weather-'+weather.code+'"></i><span class="temperature">'+weather.temp+'&deg;'+weather.units.temp+'<br /><span class="condition">'+weather.currently+'</span>';

      $("#weather").html(html);
    },
    error: function(error) {
      $("#weather").html('<p>'+error+'</p>');
    }
  });
});
