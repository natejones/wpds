<?php

/*
Plugin Name: The Weather
Plugin URI: http://pixelydo.com/work/wordpress-digital-signage/
Description: The weather for WPDS
Author: Nate Jones
Version: 1.0
Author URI: http://pixelydo.com/
*/


class weather_plugin extends WP_Widget {

// constructor
		function weather_plugin() {
				parent::WP_Widget(false, $name = __('The Weather', 'wp_widget_plugin') );
		}

// widget form creation
function form($instance) {
echo '<p>Nothing to do here. <em>Many thanks to <a href="https://twitter.com/fleetingftw">@fleetingftw</a> for <a href="http://simpleweatherjs.com/">SimpleWeatherJS</a></em>.</p>';

// Check values
?>
<?php
}

// update widget
		function update($new_instance, $old_instance) {
		}

// display widget
			function widget($args, $instance) {
				extract( $args );
				// these are the widget options
				$text = $instance['text'];
				$unit_select = $instance['select'];
				echo $before_widget;
				// Display the widget
				echo '<link rel="stylesheet" href="'. plugins_url( 'weather.css' , __FILE__ ) .'">';
				echo '<script src="'. plugins_url( 'weather.js' , __FILE__ ) .'"></script>';
				echo '<div id="weather"></div>';
				echo $after_widget;
			}
}

// register widget
add_action('widgets_init', create_function('', 'return register_widget("weather_plugin");'));
