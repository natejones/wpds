<?php

/*
Plugin Name: The Clock
Plugin URI: http://pixelydo.com/work/wordpress-digital-signage/
Description: The clock for WPDS
Author: Nate Jones
Version: 1.0
Author URI: http://pixelydo.com/
*/


class clock_plugin extends WP_Widget {

// constructor
		function clock_plugin() {
				parent::WP_Widget(false, $name = __('The Clock', 'wp_widget_plugin') );
		}

// widget form creation
function form($instance) {
echo '<p>Nothing to do here. <em>Many thanks to <a href="https://twitter.com/Bluxart">@Bluxart</a> for <a href="http://www.alessioatzeni.com/blog/css3-digital-clock-with-jquery">the original clock</a></em></p>';

// Check values
?>
<?php
}

// update widget
		function update($new_instance, $old_instance) {
		}

// display widget
			function widget($args, $instance) {
				extract( $args );
				// these are the widget options
				$text = $instance['text'];
				$unit_select = $instance['select'];
				echo $before_widget;
				// Display the widget
				//echo '<link rel="stylesheet" href="'. plugins_url( 'weather.css' , __FILE__ ) .'">';
				echo '<script src="'. plugins_url( 'clock.js' , __FILE__ ) .'"></script>';
				echo '<div class="clock"><ul><li id="hours"> </li><li id="point">:</li><li id="min"> </li></ul><div id="Date"></div></div>';
				echo $after_widget;
			}
}

// register widget
add_action('widgets_init', create_function('', 'return register_widget("clock_plugin");'));
