<?php

/*
Plugin Name: WPDS Post Details
Plugin URI: http://pixelydo.com/work/wordpress-digital-signage/
Description: WPDS post details
Author: Nate Jones
Version: 1.0
Author URI: http://pixelydo.com/
*/


/**
 * Adds a meta box to the post editing screen
 */
function wpds_custom_meta() {
	add_meta_box( 'wpds', __( 'Details', 'wpds-textdomain' ), 'wpds_meta_callback', 'post' );
}
add_action( 'add_meta_boxes', 'wpds_custom_meta' );

/**
 * Outputs the content of the meta box
 */
function wpds_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'wpds_nonce' );
	$wpds_stored_meta = get_post_meta( $post->ID );
	?>
<table class="colors">
	<tr>
		<td colspan="3">
			<p>Color reference</p>
		</td>
	</tr>
	<tr>
		<td>
			<div class="nutmeg square" title="#772b2b"></div>
		</td>
		<td>
			<div class="paco square" title="#471111"></div>
		</td>
		<td>
			<div class="laser square" title="#C6A976"></div>
		</td>
	</tr>
	<tr>
		<td>
			Nutmeg
		</td>
		<td>
			Paco
		</td>
		<td>
			Laser
		</td>
	</tr>
	<tr>
		<td>
			<div class="deep-sea-green square" title="#0B5065"></div>
		</td>
		<td>
			<div class="tarawera square" title="#0C3C4E"></div>
		</td>
		<td>
			<div class="pigeon-post square" title="#A6BDDA"></div>
		</td>
	</tr>
	<tr>
		<td>
			Deep Sea Green
		</td>
		<td>
			Tarawera
		</td>
		<td>
			Pigeon Post
		</td>
	</tr>
	<tr>
		<td>
			<div class="black-pearl square" title="#04151A"></div>
		</td>
		<td>
			<div class="hoizon square" title="#5E8DA8"></div>
		</td>
		<td>
			<div class="white square" title="#FFFFFF"></div>
		</td>
	</tr>
	<tr>
		<td>
			Black Pearl
		</td>
		<td>
			Horizon
		</td>
		<td>
			White
		</td>
	</tr>
</table>

	<p>
		<label for="subtitle" class="wpds-row-title"><?php _e( 'Subtitle', 'wpds-textdomain' )?></label>
		<input type="text" name="subtitle" id="subtitle" value="<?php if ( isset ( $wpds_stored_meta['subtitle'] ) ) echo $wpds_stored_meta['subtitle'][0]; ?>" />
	</p>
<p>
	<label for="link" class="wpds-row-title"><?php _e( 'Link for mobile viewers', 'wpds-textdomain' )?></label>
	<input type="text" name="link" id="link" value="<?php if ( isset ( $wpds_stored_meta['link'] ) ) echo $wpds_stored_meta['link'][0]; ?>" />
</p>
	<p>
		<label for="background-color" class="wpds-row-title"><?php _e( 'Background Color', 'wpds-textdomain' )?></label>
		<select name="background-color" id="background-color">
			<option value="772b2b" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], '772b2b' ); ?>><?php _e( 'Nutmeg', 'wpds-textdomain' )?></option>';
			<option value="471111" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], '471111' ); ?>><?php _e( 'Paco', 'wpds-textdomain' )?></option>';
			<option value="C6A976" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], 'C6A976' ); ?>><?php _e( 'Laser', 'wpds-textdomain' )?></option>';
			<option value="0B5065" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], '0B5065' ); ?>><?php _e( 'Deep Sea Green', 'wpds-textdomain' )?></option>';
			<option value="0C3C4E" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], '0C3C4E' ); ?>><?php _e( 'Tarawera', 'wpds-textdomain' )?></option>';
			<option value="A6BDDA" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], 'A6BDDA' ); ?>><?php _e( 'Pigeon Post', 'wpds-textdomain' )?></option>';
			<option value="04151A" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], '04151A' ); ?>><?php _e( 'Black Pearl', 'wpds-textdomain' )?></option>';
			<option value="5E8DA8" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], '5E8DA8' ); ?>><?php _e( 'Horizon', 'wpds-textdomain' )?></option>';
			<option value="FFFFFF" <?php if ( isset ( $wpds_stored_meta['background-color'] ) ) selected( $wpds_stored_meta['background-color'][0], 'FFFFFF' ); ?>><?php _e( 'White', 'wpds-textdomain' )?></option>';
		</select>
	</p>
<p>
	<label for="headline-color" class="wpds-row-title"><?php _e( 'Headline Color', 'wpds-textdomain' )?></label>
	<select name="headline-color" id="headline-color">
		<option value="772b2b" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], '772b2b' ); ?>><?php _e( 'Nutmeg', 'wpds-textdomain' )?></option>';
		<option value="471111" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], '471111' ); ?>><?php _e( 'Paco', 'wpds-textdomain' )?></option>';
		<option value="C6A976" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], 'C6A976' ); ?>><?php _e( 'Laser', 'wpds-textdomain' )?></option>';
		<option value="0B5065" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], '0B5065' ); ?>><?php _e( 'Deep Sea Green', 'wpds-textdomain' )?></option>';
		<option value="0C3C4E" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], '0C3C4E' ); ?>><?php _e( 'Tarawera', 'wpds-textdomain' )?></option>';
		<option value="A6BDDA" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], 'A6BDDA' ); ?>><?php _e( 'Pigeon Post', 'wpds-textdomain' )?></option>';
		<option value="04151A" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], '04151A' ); ?>><?php _e( 'Black Pearl', 'wpds-textdomain' )?></option>';
		<option value="5E8DA8" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], '5E8DA8' ); ?>><?php _e( 'Horizon', 'wpds-textdomain' )?></option>';
		<option value="FFFFFF" <?php if ( isset ( $wpds_stored_meta['headline-color'] ) ) selected( $wpds_stored_meta['headline-color'][0], 'FFFFFF' ); ?>><?php _e( 'White', 'wpds-textdomain' )?></option>';
	</select>
</p>
<p>
	<label for="subhead-color" class="wpds-row-title"><?php _e( 'Sub-headline Color', 'wpds-textdomain' )?></label>
	<select name="subhead-color" id="subhead-color">
		<option value="772b2b" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], '772b2b' ); ?>><?php _e( 'Nutmeg', 'wpds-textdomain' )?></option>';
		<option value="471111" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], '471111' ); ?>><?php _e( 'Paco', 'wpds-textdomain' )?></option>';
		<option value="C6A976" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], 'C6A976' ); ?>><?php _e( 'Laser', 'wpds-textdomain' )?></option>';
		<option value="0B5065" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], '0B5065' ); ?>><?php _e( 'Deep Sea Green', 'wpds-textdomain' )?></option>';
		<option value="0C3C4E" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], '0C3C4E' ); ?>><?php _e( 'Tarawera', 'wpds-textdomain' )?></option>';
		<option value="A6BDDA" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], 'A6BDDA' ); ?>><?php _e( 'Pigeon Post', 'wpds-textdomain' )?></option>';
		<option value="04151A" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], '04151A' ); ?>><?php _e( 'Black Pearl', 'wpds-textdomain' )?></option>';
		<option value="5E8DA8" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], '5E8DA8' ); ?>><?php _e( 'Horizon', 'wpds-textdomain' )?></option>';
		<option value="FFFFFF" <?php if ( isset ( $wpds_stored_meta['subhead-color'] ) ) selected( $wpds_stored_meta['subhead-color'][0], 'FFFFFF' ); ?>><?php _e( 'White', 'wpds-textdomain' )?></option>';
	</select>
</p>
<p>
	<label for="copy-color" class="wpds-row-title"><?php _e( 'Copy Color', 'wpds-textdomain' )?></label>
	<select name="copy-color" id="copy-color">
		<option value="772b2b" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], '772b2b' ); ?>><?php _e( 'Nutmeg', 'wpds-textdomain' )?></option>';
		<option value="471111" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], '471111' ); ?>><?php _e( 'Paco', 'wpds-textdomain' )?></option>';
		<option value="C6A976" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], 'C6A976' ); ?>><?php _e( 'Laser', 'wpds-textdomain' )?></option>';
		<option value="0B5065" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], '0B5065' ); ?>><?php _e( 'Deep Sea Green', 'wpds-textdomain' )?></option>';
		<option value="0C3C4E" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], '0C3C4E' ); ?>><?php _e( 'Tarawera', 'wpds-textdomain' )?></option>';
		<option value="A6BDDA" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], 'A6BDDA' ); ?>><?php _e( 'Pigeon Post', 'wpds-textdomain' )?></option>';
		<option value="04151A" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], '04151A' ); ?>><?php _e( 'Black Pearl', 'wpds-textdomain' )?></option>';
		<option value="5E8DA8" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], '5E8DA8' ); ?>><?php _e( 'Horizon', 'wpds-textdomain' )?></option>';
		<option value="FFFFFF" <?php if ( isset ( $wpds_stored_meta['copy-color'] ) ) selected( $wpds_stored_meta['copy-color'][0], 'FFFFFF' ); ?>><?php _e( 'White', 'wpds-textdomain' )?></option>';
	</select>
</p>




	<p id="bgimage">
		<label for="background-image" class="wpds-row-title"><?php _e( 'Upload a background image (if you are using one)', 'wpds-textdomain' )?></label>
		<input type="text" name="background-image" id="background-image" value="<?php if ( isset ( $wpds_stored_meta['background-image'] ) ) echo $wpds_stored_meta['background-image'][0]; ?>" />
		<input type="button" id="background-image-button" class="button" value="<?php _e( 'Choose or Upload an Image', 'wpds-textdomain' )?>" />
	</p>


	<?php
}



/**
 * Saves the custom meta input
 */
function wpds_meta_save( $post_id ) {

	// Checks save status
	$is_autosave = wp_is_post_autosave( $post_id );
	$is_revision = wp_is_post_revision( $post_id );
	$is_valid_nonce = ( isset( $_POST[ 'wpds_nonce' ] ) && wp_verify_nonce( $_POST[ 'wpds_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

	// Exits script depending on save status
	if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
		return;
	}

	// Checks for input and sanitizes/saves if needed
	if( isset( $_POST[ 'subtitle' ] ) ) {
		update_post_meta( $post_id, 'subtitle', sanitize_text_field( $_POST[ 'subtitle' ] ) );
	}
	if( isset( $_POST[ 'link' ] ) ) {
		update_post_meta( $post_id, 'link', sanitize_text_field( $_POST[ 'link' ] ) );
	}

	// Checks for input and saves if needed
	if( isset( $_POST[ 'background-color' ] ) ) {
		update_post_meta( $post_id, 'background-color', $_POST[ 'background-color' ] );
	}
	if( isset( $_POST[ 'headline-color' ] ) ) {
		update_post_meta( $post_id, 'headline-color', $_POST[ 'headline-color' ] );
	}
	if( isset( $_POST[ 'subhead-color' ] ) ) {
		update_post_meta( $post_id, 'subhead-color', $_POST[ 'subhead-color' ] );
	}
	if( isset( $_POST[ 'copy-color' ] ) ) {
		update_post_meta( $post_id, 'copy-color', $_POST[ 'copy-color' ] );
	}

	// Checks for input and saves if needed
	if( isset( $_POST[ 'background-image' ] ) ) {
		update_post_meta( $post_id, 'background-image', $_POST[ 'background-image' ] );
	}

}
add_action( 'save_post', 'wpds_meta_save' );


/**
 * Adds the meta box stylesheet when appropriate
 */
function wpds_admin_styles(){
	global $typenow;
	if( $typenow == 'post' ) {
		wp_enqueue_style( 'wpds_meta_box_styles', plugin_dir_url( __FILE__ ) . 'meta-box-styles.css' );
	}
}
add_action( 'admin_print_styles', 'wpds_admin_styles' );


/**
 * Loads the image management javascript
 */
function wpds_image_enqueue() {
	global $typenow;
	if( $typenow == 'post' ) {
		wp_enqueue_media();

		// Registers and enqueues the required javascript.
		wp_register_script( 'meta-box-image', plugin_dir_url( __FILE__ ) . 'meta-box-image.js', array( 'jquery' ) );
		wp_localize_script( 'meta-box-image', 'meta_image',
			array(
				'title' => __( 'Choose or Upload an Image', 'wpds-textdomain' ),
				'button' => __( 'Use this image', 'wpds-textdomain' ),
			)
		);
		wp_enqueue_script( 'meta-box-image' );
	}
}
add_action( 'admin_enqueue_scripts', 'wpds_image_enqueue' );
